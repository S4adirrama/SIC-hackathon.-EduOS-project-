<template>
  <Icon v-bind="$attrs" class="w-5.5 h-5.5" />
</template>

<script setup>
import { Icon } from "@iconify/vue"
</script>
