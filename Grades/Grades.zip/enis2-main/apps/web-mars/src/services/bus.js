import { createNanoEvents } from "nanoevents"

const emitter = createNanoEvents()

export { emitter }
